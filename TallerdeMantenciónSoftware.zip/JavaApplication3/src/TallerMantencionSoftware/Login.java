/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TallerMantencionSoftware;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Gabriel
 */
public class Login {
    //login simple
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.println("Ingrese Usuario");
        String nombre = leer.nextLine();
        System.out.println("Ingrese Clave");
        String clave = leer.nextLine();
        if(nombre.equals("admin")){
        if(clave.equals("1234")){
         System.out.println("Bienvenido Usuario");
        }else{
            System.out.println("Clave Incorrecta");
        }
        }else{
             System.out.println("Usuario Incorrecto");
        }
        
    }
    

public void AccederBD() throws SQLException{
        
         /*Se genera una consulta en la base de datos, que seleccione los datos solo cuando sean iguales
            al USUARIO y CLAVE, */
            Scanner leer = new Scanner(System.in);
           System.out.println("Ingrese Usuario");
           String nombre = leer.nextLine();
           System.out.println("Ingrese Clave");
           String clave = leer.nextLine();
            Connection conn = ConexionBD.conectar();
            Statement st    = conn.createStatement();
            String sql    ="select TIPO_USU,NOMBRE from usuarios where USUARIO='"+nombre+"' and CLAVE='"+clave+"'";
            ResultSet rs   = st.executeQuery(sql); 
           
            //Generamos una condición que solo se cumpla cuando la consulta es correcta
               if(rs.next()){      
                   /* Se Crea otra condición en cuanto los datos coincidan con los de la base de datos, segmente
                      el inicio, si es 1 será administrador y llevará a su menu, si es 2 este será vendedor y se 
                      abrira el menú de su respectivo usuario*/
                    String Tipo=rs.getString("tipo_usu");
                    String Nombre=rs.getString("Nombre");
                     if(Tipo.equals("1")){
                         
                         System.out.println("Bienvenido Admin");
                                
                   } if (Tipo.equals("2")){
                     System.out.println("Bienvenido Usuario");
                        }
               // En caso que los datos no coincidan enviara un mensaje de error
                         else{
                        System.out.println("Datos Incorrectos");
        }}
        }
}
