/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TallerMantencionSoftware;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Gabriel
 */
public class ConexionBD {
   
    private static final String url     ="jdbc:mysql://localhost:3306/BDLOGIN";
    private static final String usuario = "root";
    private static final String clave   = "";
    
  public static Connection conectar()
    {
        try
        {
           return DriverManager.getConnection(url, usuario, clave);
        }
        catch(SQLException c)
        {
            System.err.println("Excepción de SQL: " + c);
            return null;
        }
    }
}

